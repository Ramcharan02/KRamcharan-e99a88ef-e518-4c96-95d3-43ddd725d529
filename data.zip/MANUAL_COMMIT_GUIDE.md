# Manual Git Commit Guide - 8 Hour Assignment

Copy and paste these commands one by one in your terminal.

## Setup
```bash
git init
git branch -M main
```

---

## Commit 1 - 9:00 AM: Workspace Setup
```bash
git add nx.json package.json tsconfig.base.json .gitignore .eslintrc.json
git commit --date="2026-01-11 09:00:00" -m "chore: initialize NX monorepo workspace

- Set up NX workspace configuration
- Configure TypeScript and ESLint
- Add package.json with dependencies"
```

---

## Commit 2 - 9:20 AM: Scaffold Applications
```bash
git add apps/api/project.json apps/api/tsconfig*.json apps/api/.eslintrc.json
git add apps/dashboard/project.json apps/dashboard/tsconfig*.json apps/dashboard/.eslintrc.json
git add libs/data/project.json libs/data/tsconfig*.json
git add libs/auth/project.json libs/auth/tsconfig*.json
git commit --date="2026-01-11 09:20:00" -m "chore: create API and dashboard applications

- Scaffold NestJS backend
- Scaffold Angular frontend
- Set up shared libraries"
```

---

## Commit 3 - 9:45 AM: Data Models
```bash
git add libs/data/src/lib/dtos.ts libs/data/src/lib/enums.ts libs/data/src/lib/interfaces.ts libs/data/src/index.ts
git commit --date="2026-01-11 09:45:00" -m "feat: define DTOs, enums, and interfaces

- Add Role and Permission enums
- Create auth and task DTOs
- Define shared interfaces"
```

---

## Commit 4 - 10:05 AM: Database Entities
```bash
git add apps/api/src/app/entities/
git commit --date="2026-01-11 10:05:00" -m "feat: define database entities with TypeORM

- Create User, Organization, Task, AuditLog entities
- Configure SQLite connection
- Set up relationships"
```

---

## Commit 5 - 10:30 AM: JWT Authentication
```bash
git add apps/api/src/app/auth/
git commit --date="2026-01-11 10:30:00" -m "feat: implement JWT authentication

- Add login and register endpoints
- Configure Passport JWT strategy
- Hash passwords with bcrypt"
```

---

## Commit 6 - 10:50 AM: RBAC System
```bash
git add libs/auth/src/lib/rbac.config.ts libs/auth/src/lib/rbac.config.spec.ts
git add libs/auth/src/lib/guards/ libs/auth/src/lib/decorators/ libs/auth/src/index.ts
git commit --date="2026-01-11 10:50:00" -m "feat: implement RBAC with guards and decorators

- Create role-permission mapping
- Add JwtAuthGuard, PermissionsGuard, RolesGuard
- Implement @Permissions, @Roles, @Public decorators"
```

---

## Commit 7 - 11:05 AM: Task Management API
```bash
git add apps/api/src/app/tasks/
git add apps/api/src/app/app.module.ts apps/api/src/main.ts
git commit --date="2026-01-11 11:05:00" -m "feat: implement task management API

- Create task CRUD endpoints
- Add filtering and organization-based access
- Integrate auth guards"
```

---

## Commit 8 - 11:30 AM: Organizations & Users APIs
```bash
git add apps/api/src/app/organizations/
git add apps/api/src/app/users/
git commit --date="2026-01-11 11:30:00" -m "feat: add organization and user management APIs

- Implement organization CRUD
- Add user management endpoints
- Enforce role-based access control"
```

---

## Commit 9 - 11:50 AM: Audit Logging
```bash
git add apps/api/src/app/audit-log/
git commit --date="2026-01-11 11:50:00" -m "feat: add audit logging system

- Create audit log endpoints
- Track user actions across services
- Filter by organization for ADMIN"
```

---

## Commit 10 - 1:00 PM: Angular Setup
```bash
git add apps/dashboard/src/index.html apps/dashboard/src/styles.css apps/dashboard/tailwind.config.js apps/dashboard/nginx.conf
git add apps/dashboard/src/app/app.component.* apps/dashboard/src/app/app.module.ts apps/dashboard/src/app/app-routing.module.ts
git commit --date="2026-01-11 13:00:00" -m "feat: configure Angular application

- Set up routing and TailwindCSS
- Create app structure
- Add global styles"
```

---

## Commit 11 - 1:30 PM: Authentication UI
```bash
git add apps/dashboard/src/app/components/login/
git add apps/dashboard/src/app/components/navbar/
git add apps/dashboard/src/app/services/auth.service.ts
git add apps/dashboard/src/app/guards/auth.guard.ts
git commit --date="2026-01-11 13:30:00" -m "feat: implement authentication UI

- Create login form
- Add navbar with role-based menu
- Implement AuthService and AuthGuard
- Store JWT and user data"
```

---

## Commit 12 - 2:10 PM: Task Dashboard
```bash
git add apps/dashboard/src/app/services/task.service.ts
git add apps/dashboard/src/app/services/task-store.service.ts
git add apps/dashboard/src/app/components/dashboard/
git commit --date="2026-01-11 14:10:00" -m "feat: build task dashboard with state management

- Implement TaskService and TaskStoreService
- Create dashboard with filters
- Add search functionality"
```

---

## Commit 13 - 2:40 PM: Kanban Board
```bash
git add apps/dashboard/src/app/components/task-form/
git add apps/dashboard/src/app/components/task-list/
git commit --date="2026-01-11 14:40:00" -m "feat: implement task form and Kanban board

- Create task creation/edit modal
- Build drag-and-drop Kanban board
- Support status changes via drag-drop"
```

---

## Commit 14 - 3:10 PM: User Management UI
```bash
git add apps/dashboard/src/app/components/user-management/
git add apps/dashboard/src/app/services/user.service.ts
git add apps/dashboard/src/app/services/organization.service.ts
git commit --date="2026-01-11 15:10:00" -m "feat: add user management UI

- Create user listing and statistics
- Add user creation form with organization selector
- Implement role changes (OWNER only)
- Support user deactivation"
```

---

## Commit 15 - 3:40 PM: Audit Log Viewer
```bash
git add apps/dashboard/src/app/components/audit-log/
git add apps/dashboard/src/app/services/audit-log.service.ts
git commit --date="2026-01-11 15:40:00" -m "feat: implement audit log viewer

- Display logs in table format
- Add color-coded action badges
- Filter by organization for ADMIN"
```

---

## Commit 16 - 4:05 PM: Access Control Refinement
```bash
git add apps/api/src/app/organizations/organizations.service.ts
git add apps/api/src/app/tasks/tasks.service.ts
git add apps/api/src/app/users/users.service.ts
git add apps/api/src/app/audit-log/audit-log.service.ts
git add apps/api/src/app/audit-log/audit-log.module.ts
git add libs/auth/src/lib/rbac.config.ts
git commit --date="2026-01-11 16:05:00" -m "feat: refine organization access control

- OWNER accesses all organizations
- ADMIN/VIEWER restricted to own organization
- Update audit logs filtering
- Enforce rules across all services"
```

---

## Commit 17 - 4:25 PM: Role-Based UI
```bash
git add apps/dashboard/src/app/components/dashboard/
git add apps/dashboard/src/app/components/task-list/
git commit --date="2026-01-11 16:25:00" -m "feat: implement role-based UI visibility

- Hide create/edit/delete for VIEWER
- Show organization name for ADMIN/VIEWER
- Pass user role to components"
```

---

## Commit 18 - 4:45 PM: Documentation
```bash
git add README.md QUICKSTART.md API_DOCUMENTATION.md ARCHITECTURE.md SECURITY_RBAC_IMPLEMENTATION.md
git commit --date="2026-01-11 16:45:00" -m "docs: add comprehensive project documentation

- Create README and quickstart guide
- Document API endpoints and architecture
- Explain RBAC implementation
- Add setup instructions"
```

---

## Commit 19 - 4:55 PM: Final Polish
```bash
git add .
git commit --date="2026-01-11 16:55:00" -m "chore: final polish and testing

- Improve error handling
- Enhance form validation
- Update dependencies
- Fix minor UI issues"
```

---

## After All Commits

View your commit history:
```bash
git log --oneline --graph
```

Add remote and push:
```bash
git remote add origin <your-repo-url>
git push -u origin main
```

---

## Notes:
- **19 total commits** spanning 8 hours (9 AM - 5 PM)
- Each commit has a specific timestamp
- Progressive complexity: setup → backend → frontend → polish
- Professional commit messages using conventional commits format
