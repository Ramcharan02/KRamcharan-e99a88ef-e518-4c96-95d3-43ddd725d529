# Helpful Commands - Task Management System

## 🚀 Getting Started

```bash
# Install all dependencies
npm install

# Copy environment template
cp .env.example .env

# Seed the database with sample data
npm run seed

# Start backend API (http://localhost:3000)
npm run start:api

# Start frontend dashboard (http://localhost:4200)
npm run start:dashboard
```

## 🏗️ Build Commands

```bash
# Build everything
npm run build

# Build backend only
npm run build:api

# Build frontend only
npm run build:dashboard
```

## 🧪 Testing

```bash
# Run all tests
npm test

# Run backend tests
npm run test:api

# Run frontend tests
npm run test:dashboard

# Run specific library tests
nx test data
nx test auth

# Run tests with coverage
npm run test:coverage

# Watch mode for development
nx test api --watch
nx test dashboard --watch
```

## 🔍 Linting

```bash
# Lint all projects
npm run lint

# Lint specific project
nx lint api
nx lint dashboard
nx lint data
nx lint auth

# Auto-fix linting issues
nx lint api --fix
```

## 📦 NX Commands

```bash
# See project dependency graph
nx graph

# Run command for all affected projects
nx affected:test
nx affected:lint
nx affected:build

# Clear NX cache
nx reset

# List all projects
nx show projects
```

## 🗄️ Database

```bash
# Seed database with sample data
npm run seed

# Reset database (delete and re-seed)
rm -rf data/task-management.db
npm run seed
```

## 🐳 Docker

```bash
# Build and run with Docker Compose
docker-compose up -d

# View logs
docker-compose logs -f

# Stop containers
docker-compose down

# Rebuild containers
docker-compose up -d --build
```

## 📊 Development

```bash
# Serve API in watch mode
nx serve api

# Serve dashboard in watch mode
nx serve dashboard

# Serve with specific port
nx serve api --port=3001
nx serve dashboard --port=4201
```

## 🔧 Troubleshooting

```bash
# Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install

# Clear NX cache and dist folder
rm -rf dist .nx
nx reset

# Check for outdated packages
npm outdated

# Update dependencies
npm update
```

## 📝 Code Generation (NX)

```bash
# Generate new Angular component
nx g @nx/angular:component my-component --project=dashboard

# Generate new NestJS service
nx g @nx/nest:service my-service --project=api

# Generate new library
nx g @nx/js:library my-lib

# Generate new Angular module
nx g @nx/angular:module my-module --project=dashboard
```

## 🌐 API Testing with curl

```bash
# Register new user
curl -X POST http://localhost:3000/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "password123",
    "name": "Test User",
    "role": "VIEWER",
    "organizationId": 1
  }'

# Login
curl -X POST http://localhost:3000/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@example.com",
    "password": "password123"
  }'

# Get tasks (replace TOKEN with actual JWT)
curl -X GET http://localhost:3000/tasks \
  -H "Authorization: Bearer TOKEN"

# Create task
curl -X POST http://localhost:3000/tasks \
  -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "New Task",
    "description": "Task description",
    "category": "WORK",
    "status": "TODO",
    "priority": 5
  }'

# Get audit log
curl -X GET http://localhost:3000/audit-log \
  -H "Authorization: Bearer TOKEN"
```

## 📱 Quick Test Flow

1. **Start services:**
   ```bash
   npm run start:api  # Terminal 1
   npm run start:dashboard  # Terminal 2
   ```

2. **Open browser:** http://localhost:4200

3. **Login with:**
   - Email: `admin@example.com`
   - Password: `password123`

4. **Create a task:**
   - Click "Create Task"
   - Fill in the form
   - Submit

5. **Test filtering:**
   - Use status dropdown
   - Use category dropdown
   - Try search box

6. **Test different roles:**
   - Logout and login as `viewer@example.com`
   - Notice limited permissions (read-only)

## 🎯 Production Deployment

```bash
# Build for production
npm run build:api
npm run build:dashboard

# Using Docker
docker-compose -f docker-compose.yml up -d

# Environment variables
# Make sure to set proper JWT_SECRET in production
# Change database to PostgreSQL for production
```

## 📚 Documentation

- **README.md** - Full documentation
- **QUICKSTART.md** - Quick setup guide
- **API.md** - API endpoints reference
- **ARCHITECTURE.md** - Architecture decisions
- **PROJECT_SUMMARY.md** - Project overview
- **CHECKLIST.md** - Completion checklist

## 🆘 Common Issues

**Port already in use:**
```bash
# Find process using port 3000
lsof -i :3000
# Kill process
kill -9 <PID>
```

**Database locked:**
```bash
# Stop API server and delete database
rm data/task-management.db
npm run seed
```

**TypeScript errors:**
```bash
# Clear cache and rebuild
nx reset
npm run build
```

**Module not found:**
```bash
# Reinstall dependencies
npm install
```

## 💡 Pro Tips

- Use `nx graph` to visualize project dependencies
- Run `nx affected:test` to only test changed code
- Use `--watch` flag during development for auto-reload
- Check `.env` file for configuration options
- Use different terminals for backend and frontend
- Check browser console for frontend errors
- Check terminal output for backend errors

---

**Happy Coding!** 🚀
