# Task Management System

> Secure Full-Stack Task Management with RBAC

## Quick Start

1. Install dependencies: `npm install`
2. Copy environment: `cp .env.example .env`
3. Seed database: `npm run seed`
4. Start backend: `npm run start:api`
5. Start frontend: `npm run start:dashboard`
6. Open: http://localhost:4200

## Test Credentials

- **Owner**: owner@example.com / password123
- **Admin**: admin@example.com / password123
- **Viewer**: viewer@example.com / password123

See [README.md](README.md) for full documentation.
