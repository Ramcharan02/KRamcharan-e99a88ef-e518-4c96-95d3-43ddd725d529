const fetch = require('node-fetch');

async function createUsers() {
  const API_URL = 'http://localhost:3000';
  
  const users = [
    {
      email: 'admin2@example.com',
      password: 'password123',
      name: 'Admin User 2',
      role: 'ADMIN',
      organizationId: 1
    },
    {
      email: 'viewer@example.com',
      password: 'password123',
      name: 'Viewer User',
      role: 'VIEWER',
      organizationId: 1
    },
     {
      email: 'viewer2@example.com',
      password: 'password123',
      name: 'Viewer User 2',
      role: 'VIEWER',
      organizationId: 2
    }
  ];

  console.log('Creating test users...\n');

  for (const user of users) {
    try {
      const response = await fetch(`${API_URL}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(user)
      });

      if (response.ok) {
        const data = await response.json();
        console.log(`✓ Created ${user.role}: ${user.email}`);
      } else {
        const error = await response.text();
        console.log(`✗ Failed to create ${user.email}: ${error}`);
      }
    } catch (error) {
      console.error(`Error creating ${user.email}:`, error.message);
    }
  }

  // Verify users
  console.log('\nVerifying users...');
  try {
    const loginResponse = await fetch(`${API_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: 'admin@example.com',
        password: 'password123'
      })
    });

    const { access_token } = await loginResponse.json();

    const usersResponse = await fetch(`${API_URL}/users`, {
      headers: { 'Authorization': `Bearer ${access_token}` }
    });

    const allUsers = await usersResponse.json();
    console.log('\nUsers in database:');
    allUsers.forEach(u => {
      console.log(`  ${u.role.padEnd(7)} - ${u.email.padEnd(25)} (${u.name})`);
    });

    console.log('\n✓ Login credentials:');
    console.log('  OWNER:  admin@example.com / password123');
    console.log('  ADMIN:  admin2@example.com / password123');
    console.log('  VIEWER: viewer@example.com / password123');
  } catch (error) {
    console.error('Error verifying users:', error.message);
  }
}

createUsers();
