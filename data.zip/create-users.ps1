# Script to create test users

Write-Host "=== Creating Test Users ===" -ForegroundColor Cyan

# Admin User
Write-Host "`nCreating Admin User..." -ForegroundColor Yellow
$adminBody = @{
    email = "admin2@example.com"
    password = "password123"
    name = "Admin User 2"
    role = "ADMIN"
    organizationId = 1
} | ConvertTo-Json

try {
    $admin = Invoke-RestMethod -Uri "http://localhost:3000/auth/register" -Method POST -ContentType "application/json" -Body $adminBody
    Write-Host "✓ Admin user created: $($admin.user.email)" -ForegroundColor Green
} catch {
    Write-Host "✗ Admin user creation failed: $($_.Exception.Response.StatusCode)" -ForegroundColor Red
    if ($_.Exception.Response.StatusCode -eq 409) {
        Write-Host "  (User already exists)" -ForegroundColor Yellow
    }
}

# Viewer User
Write-Host "`nCreating Viewer User..." -ForegroundColor Yellow
$viewerBody = @{
    email = "viewer@example.com"
    password = "password123"
    name = "Viewer User"
    role = "VIEWER"
    organizationId = 1
} | ConvertTo-Json

try {
    $viewer = Invoke-RestMethod -Uri "http://localhost:3000/auth/register" -Method POST -ContentType "application/json" -Body $viewerBody
    Write-Host "✓ Viewer user created: $($viewer.user.email)" -ForegroundColor Green
} catch {
    Write-Host "✗ Viewer user creation failed: $($_.Exception.Response.StatusCode)" -ForegroundColor Red
    if ($_.Exception.Response.StatusCode -eq 409) {
        Write-Host "  (User already exists)" -ForegroundColor Yellow
    }
}

# Verify users
Write-Host "`n=== Verifying Users ===" -ForegroundColor Cyan
$loginBody = @{
    email = "admin@example.com"
    password = "password123"
} | ConvertTo-Json

try {
    $login = Invoke-RestMethod -Uri "http://localhost:3000/auth/login" -Method POST -ContentType "application/json" -Body $loginBody
    $token = $login.access_token
    
    $users = Invoke-RestMethod -Uri "http://localhost:3000/users" -Method GET -Headers @{"Authorization"="Bearer $token"}
    
    Write-Host "`nUsers in database:" -ForegroundColor Green
    $users | Format-Table id, email, name, role -AutoSize
    
    Write-Host "`nYou can now login with:" -ForegroundColor Cyan
    Write-Host "  OWNER:  admin@example.com / password123" -ForegroundColor White
    Write-Host "  ADMIN:  admin2@example.com / password123" -ForegroundColor White
    Write-Host "  VIEWER: viewer@example.com / password123" -ForegroundColor White
} catch {
    Write-Host "Failed to verify users: $($_.Exception.Message)" -ForegroundColor Red
}
