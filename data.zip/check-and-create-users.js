const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');

const db = new sqlite3.Database('./data/task-management.db');

async function checkAndCreateUsers() {
  return new Promise((resolve, reject) => {
    // First, check existing users
    db.all('SELECT id, email, name, role FROM users', [], async (err, rows) => {
      if (err) {
        console.error('Error reading users:', err);
        reject(err);
        return;
      }

      console.log('\n=== Current Users in Database ===');
      if (rows.length === 0) {
        console.log('  No users found!');
      } else {
        rows.forEach(r => {
          console.log(`  ${r.id} | ${r.role.padEnd(7)} | ${r.email.padEnd(30)} | ${r.name}`);
        });
      }

      // Check if admin2 and viewer exist
      const admin2Exists = rows.some(r => r.email === 'admin2@example.com');
      const viewerExists = rows.some(r => r.email === 'viewer@example.com');

      const usersToCreate = [{
          email: 'admin3@example.com',
          name: 'Admin User 3',
          role: 'ADMIN',
          organizationId: 2
        },{
          email: 'viewer2@example.com',
          name: 'Viewer User 2',
          role: 'VIEWER',
          organizationId: 2
        }];

      if (!admin2Exists) {
        usersToCreate.push({
          email: 'admin2@example.com',
          name: 'Admin User 2',
          role: 'ADMIN',
          organizationId: 1
        });
      }

      if (!viewerExists) {
        usersToCreate.push({
          email: 'viewer@example.com',
          name: 'Viewer User',
          role: 'VIEWER',
          organizationId: 1
        });
      }

      if (usersToCreate.length === 0) {
        console.log('\n✓ All test users already exist!');
        db.close();
        resolve();
        return;
      }

      console.log(`\n=== Creating ${usersToCreate.length} missing users ===`);

      // Hash password
      const hashedPassword = await bcrypt.hash('password123', 10);

      // Insert users
      const stmt = db.prepare('INSERT INTO users (email, password, name, role, organizationId, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, datetime("now"), datetime("now"))');

      for (const user of usersToCreate) {
        stmt.run([user.email, hashedPassword, user.name, user.role, user.organizationId], (err) => {
          if (err) {
            console.error(`  ✗ Failed to create ${user.email}:`, err.message);
          } else {
            console.log(`  ✓ Created ${user.role}: ${user.email}`);
          }
        });
      }

      stmt.finalize(() => {
        // Read again to verify
        db.all('SELECT id, email, name, role FROM users', [], (err, rows) => {
          if (err) {
            console.error(err);
          } else {
            console.log('\n=== Updated Users in Database ===');
            rows.forEach(r => {
              console.log(`  ${r.id} | ${r.role.padEnd(7)} | ${r.email.padEnd(30)} | ${r.name}`);
            });

            console.log('\n✓ Login Credentials:');
            console.log('  OWNER:  admin@example.com / password123');
            console.log('  ADMIN:  admin2@example.com / password123');
            console.log('  VIEWER: viewer@example.com / password123');
          }
          db.close();
          resolve();
        });
      });
    });
  });
}

checkAndCreateUsers().catch(console.error);
