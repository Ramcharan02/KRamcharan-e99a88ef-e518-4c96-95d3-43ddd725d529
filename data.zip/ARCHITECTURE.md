# Architecture Decision Records

## ADR-001: NX Monorepo Architecture

**Status**: Accepted

**Context**: Need to share TypeScript types between frontend and backend while maintaining clean separation.

**Decision**: Use NX monorepo with separate apps for API and Dashboard, and shared libraries for data models and auth logic.

**Consequences**:
- ✅ Type safety across the stack
- ✅ Code reusability
- ✅ Single source of truth for DTOs
- ⚠️ Larger initial setup
- ⚠️ Learning curve for NX

---

## ADR-002: JWT Authentication

**Status**: Accepted

**Context**: Need secure, stateless authentication for API.

**Decision**: Implement JWT-based authentication with bcrypt password hashing.

**Consequences**:
- ✅ Stateless authentication
- ✅ Scalable across multiple servers
- ✅ Standard industry practice
- ⚠️ Token storage security concerns (mitigated by localStorage with HTTPS)

---

## ADR-003: RBAC with Decorators

**Status**: Accepted

**Context**: Need fine-grained access control for different user roles.

**Decision**: Implement RBAC using NestJS guards and custom decorators.

**Consequences**:
- ✅ Clean, declarative permission checks
- ✅ Reusable across all controllers
- ✅ Easy to audit and maintain
- ✅ Follows NestJS best practices

---

## ADR-004: NgRx Component Store

**Status**: Accepted

**Context**: Need state management for Angular app without full NgRx complexity.

**Decision**: Use NgRx Component Store for local component state management.

**Consequences**:
- ✅ Reactive state management
- ✅ Simpler than full NgRx Store
- ✅ Built-in side effect handling
- ✅ Good for medium-sized apps

---

## ADR-005: SQLite for Development

**Status**: Accepted

**Context**: Need simple database setup for development and demo.

**Decision**: Use SQLite for development; easily switchable to PostgreSQL for production.

**Consequences**:
- ✅ Zero-configuration database
- ✅ File-based, easy to reset
- ✅ TypeORM makes switching to PostgreSQL trivial
- ⚠️ Not suitable for production at scale
