# Task Management System - Secure RBAC Implementation

> Full Stack Coding Challenge: Secure Task Management System with Role-Based Access Control

## 📋 Table of Contents

- [Overview](#overview)
- [Architecture](#architecture)
- [Data Model](#data-model)
- [Access Control Implementation](#access-control-implementation)
- [Setup Instructions](#setup-instructions)
- [API Documentation](#api-documentation)
- [Testing](#testing)
- [Features](#features)
- [Future Considerations](#future-considerations)

---

## 🎯 Overview

This project is a full-stack task management system built with:
- **Backend**: NestJS + TypeORM + SQLite + JWT Authentication
- **Frontend**: Angular + TailwindCSS + NgRx Component Store
- **Monorepo**: NX Workspace for modular architecture
- **Security**: JWT-based authentication with comprehensive RBAC

### Key Features

✅ **Real JWT Authentication** - No mock authentication  
✅ **Role-Based Access Control (RBAC)** - Owner, Admin, Viewer roles  
✅ **Organizational Hierarchy** - 2-level organization structure  
✅ **Task Management** - Create, Read, Update, Delete with permissions  
✅ **Audit Logging** - Complete action tracking  
✅ **Responsive UI** - Mobile-first design with TailwindCSS  
✅ **State Management** - NgRx Component Store  
✅ **Comprehensive Testing** - Jest for both backend and frontend  

---

## 🏗 Architecture

### NX Monorepo Structure

```
task-management/
├── apps/
│   ├── api/                    # NestJS Backend
│   │   ├── src/
│   │   │   ├── app/
│   │   │   │   ├── entities/   # TypeORM Entities
│   │   │   │   ├── auth/       # Authentication Module
│   │   │   │   ├── tasks/      # Tasks Module
│   │   │   │   ├── users/      # Users Module
│   │   │   │   ├── organizations/  # Organizations Module
│   │   │   │   └── audit-log/  # Audit Logging Module
│   │   │   └── main.ts
│   │   └── ...
│   └── dashboard/              # Angular Frontend
│       ├── src/
│       │   ├── app/
│       │   │   ├── components/ # UI Components
│       │   │   ├── services/   # HTTP & State Services
│       │   │   ├── guards/     # Auth Guards
│       │   │   └── interceptors/ # HTTP Interceptors
│       │   └── main.ts
│       └── ...
├── libs/
│   ├── data/                   # Shared TypeScript Interfaces & DTOs
│   │   └── src/
│   │       └── lib/
│   │           ├── enums.ts
│   │           ├── interfaces.ts
│   │           └── dtos.ts
│   └── auth/                   # Shared RBAC Logic
│       └── src/
│           └── lib/
│               ├── rbac.config.ts
│               ├── decorators.ts
│               ├── guards.ts
│               └── strategies.ts
└── ...
```

### Rationale for NX Monorepo

1. **Code Sharing**: Shared DTOs and interfaces between frontend and backend ensure type safety
2. **Consistency**: Same TypeScript types across the stack
3. **Reusability**: RBAC logic can be reused across multiple applications
4. **Developer Experience**: Single npm install, unified tooling
5. **Scalability**: Easy to add new apps or libraries

---

## 💾 Data Model

### Entity Relationship Diagram

```
┌─────────────────┐       ┌──────────────────┐
│  Organization   │◄──────│  Organization    │
│─────────────────│       │  (Parent)        │
│ id              │       └──────────────────┘
│ name            │
│ parentOrgId     │
│ createdAt       │       ┌──────────────────┐
│ updatedAt       │       │      User        │
└────────┬────────┘       │──────────────────│
         │                │ id               │
         │                │ email            │
         │                │ password (hash)  │
         │                │ name             │
         │                │ role             │
         └───────────────►│ organizationId   │
                          │ createdAt        │
                          │ updatedAt        │
                          └────────┬─────────┘
                                   │
                                   │
                          ┌────────▼─────────┐
                          │      Task        │
                          │──────────────────│
                          │ id               │
                          │ title            │
                          │ description      │
                          │ status           │
                          │ category         │
                          │ priority         │
                          │ dueDate          │
                          │ createdById      │
                          │ organizationId   │
                          │ createdAt        │
                          │ updatedAt        │
                          └──────────────────┘

┌──────────────────┐
│   AuditLog       │
│──────────────────│
│ id               │
│ userId           │
│ action           │
│ resource         │
│ resourceId       │
│ details          │
│ ipAddress        │
│ timestamp        │
└──────────────────┘
```

### Schema Details

#### **Users Table**
- `id`: Primary key
- `email`: Unique, used for login
- `password`: Bcrypt hashed (10 rounds)
- `name`: User's full name
- `role`: ENUM (OWNER, ADMIN, VIEWER)
- `organizationId`: Foreign key to Organizations
- Timestamps: `createdAt`, `updatedAt`

#### **Organizations Table**
- `id`: Primary key
- `name`: Organization name
- `parentOrganizationId`: Self-referencing FK (2-level hierarchy)
- Supports parent-child relationships
- Timestamps: `createdAt`, `updatedAt`

#### **Tasks Table**
- `id`: Primary key
- `title`: Task title (max 200 chars)
- `description`: Detailed description (text)
- `status`: ENUM (TODO, IN_PROGRESS, DONE)
- `category`: ENUM (WORK, PERSONAL, URGENT, OTHER)
- `priority`: Integer (0-10)
- `dueDate`: Optional deadline
- `createdById`: FK to Users
- `organizationId`: FK to Organizations
- Timestamps: `createdAt`, `updatedAt`

#### **AuditLog Table**
- `id`: Primary key
- `userId`: FK to Users
- `action`: Action performed (CREATE, READ, UPDATE, DELETE)
- `resource`: Resource type (Task, User, etc.)
- `resourceId`: ID of affected resource
- `details`: JSON or text details
- `ipAddress`: Client IP (optional)
- `timestamp`: When action occurred

---

## 🔐 Access Control Implementation

### Role Hierarchy

```
OWNER > ADMIN > VIEWER
```

### Role-Permission Matrix

| Permission              | OWNER | ADMIN | VIEWER |
|------------------------|-------|-------|--------|
| CREATE_TASK            | ✅    | ✅    | ❌     |
| READ_TASK              | ✅    | ✅    | ✅     |
| UPDATE_TASK            | ✅    | ✅    | ❌     |
| DELETE_TASK            | ✅    | ✅    | ❌     |
| VIEW_AUDIT_LOG         | ✅    | ✅    | ❌     |
| MANAGE_USERS           | ✅    | ✅    | ❌     |
| MANAGE_ORGANIZATION    | ✅    | ❌    | ❌     |

### Organization Access Rules

1. **Viewer**: Can only access resources in their own organization
2. **Admin**: Can access their organization + child organizations
3. **Owner**: Can access their organization + child organizations + full management rights

### Implementation Details

#### Backend Guards (NestJS)

```typescript
// 1. JWT Authentication Guard
@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {
  // Validates JWT token on every request
  // Attaches user payload to request object
}

// 2. Roles Guard
@Injectable()
export class RolesGuard implements CanActivate {
  // Checks if user has required role(s)
  // Uses @Roles() decorator metadata
}

// 3. Permissions Guard
@Injectable()
export class PermissionsGuard implements CanActivate {
  // Checks if user's role has required permission(s)
  // Uses @Permissions() decorator metadata
}
```

#### JWT Integration

**Token Structure:**
```json
{
  "userId": 1,
  "email": "admin@example.com",
  "role": "ADMIN",
  "organizationId": 1,
  "iat": 1234567890,
  "exp": 1234571490
}
```

**Flow:**
1. User logs in with email/password
2. Backend validates credentials and generates JWT
3. Frontend stores token in localStorage
4. All subsequent requests include token in Authorization header
5. Backend validates token on each request
6. Guards check permissions based on user role

#### Frontend Guards (Angular)

```typescript
@Injectable()
export class AuthGuard implements CanActivate {
  // Prevents unauthorized access to routes
  // Redirects to login if no valid token
}
```

#### HTTP Interceptor

```typescript
@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  // Automatically adds JWT to all HTTP requests
  // Handles 401 errors and redirects to login
}
```

---

## 🚀 Setup Instructions

### Prerequisites

- Node.js (v18 or higher)
- npm or yarn
- Git

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd Assign1
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env
   ```
   
   Edit `.env` with your configuration:
   ```env
   JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
   JWT_EXPIRATION=1h
   DB_TYPE=sqlite
   DB_DATABASE=./data/task-management.db
   API_PORT=3000
   CORS_ORIGIN=http://localhost:4200
   ```

4. **Initialize database with seed data**
   ```bash
   npm run seed
   ```

### Running the Applications

#### Start Backend (API)
```bash
npm run start:api
```
API will be available at: `http://localhost:3000`

#### Start Frontend (Dashboard)
```bash
npm run start:dashboard
```
Dashboard will be available at: `http://localhost:4200`

#### Run Both Simultaneously
```bash
# Terminal 1
npm run start:api

# Terminal 2
npm run start:dashboard
```

### Default Test Credentials

After running the seed script, use these credentials:

**Owner Account:**
- Email: `owner@example.com`
- Password: `password123`
- Organization: TechCorp (Parent)

**Admin Account:**
- Email: `admin@example.com`
- Password: `password123`
- Organization: TechCorp Engineering (Child)

**Viewer Account:**
- Email: `viewer@example.com`
- Password: `password123`
- Organization: TechCorp Engineering (Child)

---

## 📚 API Documentation

### Base URL
```
http://localhost:3000
```

### Authentication Endpoints

#### **POST /auth/register**
Register a new user

**Request:**
```json
{
  "email": "user@example.com",
  "password": "password123",
  "name": "John Doe",
  "role": "VIEWER",
  "organizationId": 1
}
```

**Response:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "email": "user@example.com",
    "name": "John Doe",
    "role": "VIEWER",
    "organizationId": 1
  }
}
```

#### **POST /auth/login**
Login with existing credentials

**Request:**
```json
{
  "email": "admin@example.com",
  "password": "password123"
}
```

**Response:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 2,
    "email": "admin@example.com",
    "name": "Admin User",
    "role": "ADMIN",
    "organizationId": 1
  }
}
```

### Task Endpoints

#### **POST /tasks**
Create a new task
- **Required Permission**: `CREATE_TASK`
- **Headers**: `Authorization: Bearer <token>`

**Request:**
```json
{
  "title": "Complete project documentation",
  "description": "Write comprehensive README",
  "category": "WORK",
  "status": "TODO",
  "priority": 8,
  "dueDate": "2026-01-15T00:00:00.000Z"
}
```

**Response:**
```json
{
  "id": 1,
  "title": "Complete project documentation",
  "description": "Write comprehensive README",
  "category": "WORK",
  "status": "TODO",
  "priority": 8,
  "dueDate": "2026-01-15T00:00:00.000Z",
  "createdById": 2,
  "organizationId": 1,
  "createdAt": "2026-01-09T10:00:00.000Z",
  "updatedAt": "2026-01-09T10:00:00.000Z"
}
```

#### **GET /tasks**
Get all accessible tasks
- **Required Permission**: `READ_TASK`
- **Headers**: `Authorization: Bearer <token>`

**Response:**
```json
[
  {
    "id": 1,
    "title": "Complete project documentation",
    "description": "Write comprehensive README",
    "category": "WORK",
    "status": "TODO",
    "priority": 8,
    "createdById": 2,
    "organizationId": 1,
    "createdAt": "2026-01-09T10:00:00.000Z",
    "updatedAt": "2026-01-09T10:00:00.000Z"
  }
]
```

#### **GET /tasks/:id**
Get a specific task
- **Required Permission**: `READ_TASK`
- **Headers**: `Authorization: Bearer <token>`

#### **PUT /tasks/:id**
Update a task
- **Required Permission**: `UPDATE_TASK`
- **Headers**: `Authorization: Bearer <token>`

**Request:**
```json
{
  "status": "IN_PROGRESS",
  "priority": 9
}
```

#### **DELETE /tasks/:id**
Delete a task
- **Required Permission**: `DELETE_TASK`
- **Headers**: `Authorization: Bearer <token>`

### Audit Log Endpoints

#### **GET /audit-log**
View audit logs (last 100 entries)
- **Required Permission**: `VIEW_AUDIT_LOG`
- **Headers**: `Authorization: Bearer <token>`

**Response:**
```json
[
  {
    "id": 1,
    "userId": 2,
    "action": "CREATE",
    "resource": "Task",
    "resourceId": 1,
    "details": "Created task: Complete project documentation",
    "timestamp": "2026-01-09T10:00:00.000Z"
  }
]
```

### Organization Endpoints

#### **GET /organizations**
Get all organizations (public endpoint)

#### **GET /organizations/:id**
Get organization details (public endpoint)

### User Endpoints

#### **GET /users/me**
Get current user profile
- **Headers**: `Authorization: Bearer <token>`

#### **GET /users**
Get all users
- **Required Permission**: `MANAGE_USERS`

---

## 🧪 Testing

### Run All Tests
```bash
npm test
```

### Run Backend Tests
```bash
nx test api
```

### Run Frontend Tests
```bash
nx test dashboard
```

### Run Library Tests
```bash
nx test data
nx test auth
```

### Test Coverage
```bash
npm test -- --coverage
```

### Test Structure

**Backend Tests** (`apps/api`):
- Auth service tests (JWT generation, login validation)
- RBAC logic tests (permission checking)
- Controller tests (endpoint behavior)
- Guard tests (access control)

**Frontend Tests** (`apps/dashboard`):
- Service tests (HTTP calls, state management)
- Component tests (UI behavior)
- Guard tests (route protection)
- Interceptor tests (token injection)

**Library Tests** (`libs/auth`):
- RBAC configuration tests
- Permission checking logic
- Role hierarchy validation

---

## ✨ Features

### Backend Features

- ✅ **JWT Authentication**: Secure token-based auth
- ✅ **Password Hashing**: Bcrypt with salt rounds
- ✅ **RBAC Guards**: Decorators for role/permission checking
- ✅ **Organizational Scoping**: Hierarchical access control
- ✅ **Audit Logging**: All actions logged to database
- ✅ **Input Validation**: class-validator DTOs
- ✅ **Error Handling**: Proper HTTP status codes
- ✅ **CORS Configuration**: Secure cross-origin requests

### Frontend Features

- ✅ **Responsive Design**: Mobile-first with TailwindCSS
- ✅ **State Management**: NgRx Component Store
- ✅ **Real-time Filtering**: Status, category, search
- ✅ **Task Priority**: Visual indicators (🔥, ⚡, 📌)
- ✅ **Form Validation**: Reactive forms with validators
- ✅ **Auth Guards**: Protected routes
- ✅ **HTTP Interceptor**: Automatic token injection
- ✅ **Error Handling**: User-friendly error messages
- ✅ **Loading States**: Visual feedback

---

## 🔮 Future Considerations

### Advanced Features

1. **JWT Refresh Tokens**
   - Implement token refresh mechanism
   - Automatic token renewal before expiration
   - Revocation list for invalidated tokens

2. **Advanced Role Delegation**
   - Custom role creation
   - Fine-grained permission assignment
   - Time-based role assignments
   - Temporary elevated privileges

3. **Production-Ready Security**
   - CSRF protection (Double Submit Cookie pattern)
   - Rate limiting (prevent brute force attacks)
   - Helmet.js for security headers
   - Input sanitization against XSS
   - SQL injection prevention (already handled by TypeORM)
   - Secrets management (AWS Secrets Manager, HashiCorp Vault)

4. **RBAC Caching**
   - Redis cache for permission lookups
   - Reduced database queries
   - Cache invalidation strategies

5. **Scalability Improvements**
   - Database indexing optimization
   - Query performance monitoring
   - Horizontal scaling with load balancers
   - Microservices architecture
   - Event-driven architecture (message queues)

6. **Enhanced Audit Logging**
   - Export audit logs to external systems
   - Real-time audit alerts
   - Compliance reporting
   - Log rotation and archival

7. **UI/UX Enhancements**
   - Drag-and-drop task reordering
   - Kanban board view
   - Task completion visualization (charts)
   - Dark/light mode toggle
   - Keyboard shortcuts
   - Notification system
   - Collaborative features (comments, mentions)

8. **Testing & Quality**
   - E2E testing with Cypress/Playwright
   - Integration tests
   - Performance testing
   - Security audits (npm audit, Snyk)
   - Code coverage >80%

9. **DevOps & Deployment**
   - Docker containerization
   - CI/CD pipelines (GitHub Actions, GitLab CI)
   - Environment-based deployments
   - Database migrations (TypeORM migrations)
   - Monitoring and logging (ELK stack, Datadog)

10. **Advanced Task Features**
    - Recurring tasks
    - Task dependencies
    - Sub-tasks
    - Task templates
    - File attachments
    - Task history/versioning

---

## 📝 License

MIT

---

## 👤 Author

Created as part of the Full Stack Coding Challenge

---

## 🙏 Acknowledgments

- NestJS framework
- Angular framework
- NX monorepo tools
- TailwindCSS
- TypeORM
- JWT authentication libraries

